start util.exe cert.txt
